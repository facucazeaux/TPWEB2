# TPWEB2
primera entrega del tpe


primera entrega del tpe
 Integrantes = Facundo Cazeaux y Thomas Arnaiz
la idea que tenemos es hacer una pagina de series con sus respectiva informacion de cada una ya sea los capitulos, las temporadas, un resumen, el director y protagonistas.

ACLARACION : no sabemos bien porque pero cuando descargamos la carpeta nos aparecen los archivos viejos como pueden ser carpetas model controller con los primeros archivos que subimos, pero las carpetas completas se
encuentran en apps



Usuario = webadmin
Contraseña = admin
![diagrama](https://github.com/user-attachments/assets/cf91ed9b-3757-400d-a422-8aed5cec0d6e)
