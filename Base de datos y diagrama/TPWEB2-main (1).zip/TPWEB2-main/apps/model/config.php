<?php
    const MYSQL_USER = 'root';
    const MYSQL_PASS = '';
    const MYSQL_DB = 'serie';
    const MYSQL_HOST = 'localhost';
