<?php

    class ViewAuth
        {   
            private $user = null;

            public function ShowLogin($error = '')
                {
                    require 'apps/templades/form_login.phtml';
                }


        }



?>