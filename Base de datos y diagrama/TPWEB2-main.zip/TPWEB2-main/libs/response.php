<?php
    class Response
        {
            public $user = null;
        }